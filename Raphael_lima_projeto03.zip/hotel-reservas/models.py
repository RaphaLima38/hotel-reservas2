# models.py
from typing import List

class Pessoa:
    def __init__(self, _id: int, nome: str, email: str):
        self._id = _id         # encapsulado
        self._nome = nome
        self._email = email

    def get_id(self) -> int: return self._id
    def get_nome(self) -> str: return self._nome
    def get_email(self) -> str: return self._email

class Hospede(Pessoa):
    def __init__(self, _id, nome, email):
        super().__init__(_id, nome, email)
        self._reservas: List['Reserva'] = []

    def consultar_reservas(self) -> List['Reserva']:
        return list(self._reservas)

class Funcionario(Pessoa):
    def add_quarto(self, hotel: 'Hotel', quarto: 'Quarto'):
        hotel.add_quarto(quarto)
    def registrar_hospede(self, hotel: 'Hotel', hosp: Hospede):
        hotel.registrar_hospede(hosp)
    def cancelar_reserva(self, hotel: 'Hotel', reserva: 'Reserva'):
        hotel.cancelar_reserva(reserva)

class Quarto:
    def __init__(self, numero: int, tipo: str):
        self._numero = numero
        self._tipo = tipo
        self._disponivel = True

    def reservar(self):
        if not self._disponivel:
            raise ValueError(f"Quarto {self._numero} não disponível")
        self._disponivel = False

    def liberar(self):
        self._disponivel = True

    def esta_disponivel(self) -> bool:
        return self._disponivel

class Reserva:
    def __init__(self, hospede: Hospede, quarto: Quarto):
        self.hospede = hospede       # composição
        self.quarto = quarto

class Hotel:
    def __init__(self):
        self._quartos: List[Quarto] = []     # estrutura de dados: lista
        self._hospedes: List[Hospede] = []
        self._reservas: List[Reserva] = []

    def add_quarto(self, quarto: Quarto):
        self._quartos.append(quarto)

    def registrar_hospede(self, hosp: Hospede):
        self._hospedes.append(hosp)

    def fazer_reserva(self, hosp: Hospede, quarto: Quarto) -> Reserva:
        if not quarto.esta_disponivel():
            raise ValueError("Conflito: quarto ocupado")
        quarto.reservar()
        res = Reserva(hosp, quarto)
        self._reservas.append(res)
        hosp._reservas.append(res)
        return res

    def cancelar_reserva(self, res: Reserva):
        res.quarto.liberar()
        self._reservas.remove(res)
        res.hospede._reservas.remove(res)
        