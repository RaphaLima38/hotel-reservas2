# main.py
from models import Hotel, Quarto, Hospede, Funcionario

def menu():
    print("""
    === Hotel Reservas ===
    1) Criar quarto
    2) Criar hóspede
    3) Fazer reserva
    4) Cancelar reserva
    5) Listar reservas
    0) Sair
    """)
    return input("Opção> ").strip()

def main():
    hotel = Hotel()
    func = Funcionario(0, "Admin", "admin@hotel.com")
    while True:
        op = menu()
        if op == "1":
            raw = input("Número do quarto: ").strip()
            if not raw.isdigit():
                print("Número inválido! Informe um número."); continue
            num = int(raw)
            tipo = input("Tipo do quarto: ")
            func.add_quarto(hotel, Quarto(num, tipo))
            print(f"Quarto {num} criado.")
        elif op == "2":
            raw = input("ID do hóspede: ").strip()
            if not raw.isdigit():
                print("ID inválido! Informe um número."); continue
            hid = int(raw)
            nome = input("Nome: ")
            email = input("Email: ")
            func.registrar_hospede(hotel, Hospede(hid, nome, email))
            print(f"Hóspede {nome} cadastrado.")
        elif op == "3":
            raw_hid = input("ID do hóspede: ").strip()
            if not raw_hid.isdigit():
                print("ID inválido! Informe um número."); continue
            hid = int(raw_hid)
            raw_num = input("Número do quarto: ").strip()
            if not raw_num.isdigit():
                print("Número inválido! Informe um número."); continue
            num = int(raw_num)

            hosp = next((h for h in hotel._hospedes if h.get_id() == hid), None)
            quarto = next((q for q in hotel._quartos if q._numero == num), None)
            if not hosp:
                print(f"Hóspede com ID {hid} não encontrado."); continue
            if not quarto:
                print(f"Quarto {num} não encontrado."); continue

            try:
                res = hotel.fazer_reserva(hosp, quarto)
                print(f"Reserva feita: {hosp.get_nome()} → Quarto {num}")
            except ValueError as e:
                print("Erro ao reservar:", e)
        elif op == "4":
            if not hotel._reservas:
                print("Nenhuma reserva para cancelar."); continue
            for i, res in enumerate(hotel._reservas):
                print(i, res.hospede.get_nome(), "→", res.quarto._numero)
            raw_idx = input("Índice a cancelar: ").strip()
            if not raw_idx.isdigit():
                print("Índice inválido! Informe um número."); continue
            idx = int(raw_idx)
            if 0 <= idx < len(hotel._reservas):
                func.cancelar_reserva(hotel, hotel._reservas[idx])
                print("Reserva cancelada.")
            else:
                print("Índice fora de alcance.")
        elif op == "5":
            if not hotel._reservas:
                print("Sem reservas ativas.")
            else:
                for res in hotel._reservas:
                    print(res.hospede.get_nome(), "→ Quarto", res.quarto._numero)
        elif op == "0":
            print("Saindo…")
            break
        else:
            print("Opção inválida.")
        print()

if __name__ == "__main__":
    main()