import pytest
from models import Hotel, Quarto, Hospede

def test_reserva_basica():
    h = Hotel()
    q = Quarto(1,"A")
    h.add_quarto(q)
    hosp = Hospede(1,"X","x@ex")
    h.registrar_hospede(hosp)
    res = h.fazer_reserva(hosp,q)
    assert not q.esta_disponivel()
    h.cancelar_reserva(res)
    assert q.esta_disponivel()

def test_conflito():
    h = Hotel()
    q = Quarto(1,"A"); h.add_quarto(q)
    h.registrar_hospede(Hospede(1,"X","x@ex"))
    h.registrar_hospede(Hospede(2,"Y","y@ex"))
    r1 = h.fazer_reserva(h._hospedes[0], q)
    with pytest.raises(ValueError):
        h.fazer_reserva(h._hospedes[1], q)
