# tests/conftest.py

import sys, os

# insere a pasta pai de tests (que é o root do projeto) no sys.path
root = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
if root not in sys.path:
    sys.path.insert(0, root)
